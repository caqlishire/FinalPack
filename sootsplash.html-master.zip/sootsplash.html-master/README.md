# Linux-Project-Repository
2461-71/70 Webpage Linux Repository

To add your information into the webpage, please use the "Issues" tab and provide your first name, team name, and Github ID. I will update the changes.

To make changes to your Webpage use the "Pull request" tab to edit your team's html document

I will review and commit changes :)
