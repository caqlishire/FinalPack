# FinalPack
![monday-motivation](https://user-images.githubusercontent.com/35381239/39270608-35a9170e-489c-11e8-8d5c-2273ee18f009.png)


##### <p> Im going to put all my work together after dedicated and committed to requirements for the class including, weekly homeworks, group project contributions, Case study, reading the chapters in the book before attending lecture, attending extra classes, doing extra research on website to enhance my understanding, and attending all sixeenthy weeks of class without missing out a single day, and participating in all class activities, groups like Opps and my Linux star both simultaneously.</p> 
