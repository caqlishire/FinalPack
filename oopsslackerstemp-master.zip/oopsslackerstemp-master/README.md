# oopsslackerstemp
Temporary location for Oops Slackers netbooting project documentation
