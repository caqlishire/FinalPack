# FTP-SERVER-ON-RASPBERRY-PI
Bash script to setup Web and FTP server after a fresh install of Arch on a Raspberry Pi.
