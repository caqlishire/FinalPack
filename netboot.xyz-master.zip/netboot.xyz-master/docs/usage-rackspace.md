# Rackspace

See [boot.rackspace.com](http://boot.rackspace.com) for now.  You can chain to netboot.xyz from there:

    chain --autofree https://boot.netboot.xyz
