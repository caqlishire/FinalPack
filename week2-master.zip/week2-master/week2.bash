#!/bin/bash
echo "Abshir Ali"
echo "My first script"
echo "where we at"
pwd
echo "lets create our first file"
touch file1
echo "check the file you just created"
ls
echo "lets create our second file"
touch file2
echo "run file1"
cat file1
echo "some files"
mkdir dir1
echo "copy file"
cp file1 dir1
echo "Delete file"
rm file1
echo ""
cd dir1
echo "Where we are"
pwd
echo "move file1"
mv file1 ..
echo "change the directory"
cd ..
echo "moved back file1 to his oroginal spot"
mkdir dir1
#my first script i hope this goes well
