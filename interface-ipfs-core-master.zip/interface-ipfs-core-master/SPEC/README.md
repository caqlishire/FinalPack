# IPFS Core API

This directory contains the description of the core IPFS API. In order to be considered "valid", an IPFS core implementation must expose the API described here. You can also use this loose spec as documentation for consuming the core APIs. There is an outline of the contents of that directory in the [API section of this repository's root README file](../README.md#api).
