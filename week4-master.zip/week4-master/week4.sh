#!/bin/bash
echo "my homework for week 4 csript"
echo "My name"
Abshir Ali
echo "where we are"
pwd
cat /sys/block/sdf/sdf2
echo "lets create firs file system togethe"
mkfs -t ext4 /dev/sdf2
echo "run some filessystem"
ls -l /sbin/mksf.*
echo "Mount filesystem"
mount
echo "mount littke deep"
mount -t ext4 /dev/sdf2 
echo "view and show the sie and utilization of current filesystem"
df
echo "run fsck on mounted file system"
fsck /dev/sdbl
echo "Output current swap usage"
free
echo "create a synbolic link"
echo a > dir_1/file_1
echo b > dir_1/file_2
echo c > dir_1/file_3
echo d > dir_2/file_4
ln dir_1/file_3 dir_2/file_5
ls -i
#This is my homework for chapter 4 i used what i got from the book please review and comments and i will do yours as well thank you
